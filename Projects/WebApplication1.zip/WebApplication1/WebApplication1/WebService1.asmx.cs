﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Net;
using mail = System.Net.Mail;
using my = MySql.Data;


namespace WebApplication1
{
    /// <summary>
    /// Summary description for WebService1
    /// </summary>
    [WebService(Namespace = "http://SampleWebApp1.com")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class WebService1 : System.Web.Services.WebService
    {


        public class Stock
        {
            public string stockTicker;
            public double price;

            public Stock(string stockTicker, double price)
            {
                this.stockTicker = stockTicker;
                this.price = price;
            }

            public Stock()
            {
                this.stockTicker = "";
                this.price = 0.0;
            }
            public override string ToString()
            {
                return stockTicker + " " + price;
            }

        }

        public my.MySqlClient.MySqlConnection connectToDatabase()
        {

            my.MySqlClient.MySqlConnection conn = null;

            string strConnectionString = "Server=localhost;Database=test;Uid=root;Pwd=1234;";

            conn = new my.MySqlClient.MySqlConnection(strConnectionString);

            try
            {
                conn.Open();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message.ToString());
            }

            return conn;
        }

        public void LocalSetupGet(my.MySqlClient.MySqlConnection conn)
        {
            string strQuery = String.Empty;

            strQuery = string.Format("SELECT * FROM app_performance.activity WHERE process_exittime BETWEEN '2016-10-06 11:00:30' AND '2016-11-09 20:21:30';");

            my.MySqlClient.MySqlCommand cmd = new my.MySqlClient.MySqlCommand(strQuery, conn);

            my.MySqlClient.MySqlDataReader myReader = null;

            try
            {
                myReader = cmd.ExecuteReader();
                int n = 0;
                var filepath = @"C:\Users\fcs-bithub1\Desktop\test.txt"; //Add A filepath - parameter?
                var csv = new System.Text.StringBuilder();

                while (myReader.Read())
                {
                    var line = string.Format("{0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11},{12},{13},{14},{15},{16},{17},{18},{19}", myReader.GetString(n), myReader.GetString(n+1), myReader.GetString(n+2), myReader.GetString(n+3), myReader.GetString(n+4), myReader.GetString(n+5), myReader.GetDateTime(n+6), myReader.GetInt64(n+7), myReader.GetString(n+8), myReader.GetDateTime(n+9), myReader.GetString(n+10), myReader.GetString(n+11), myReader.GetString(n+12), myReader.GetString(n+13), myReader.GetString(n+14), myReader.GetString(n+15), myReader.GetString(n+16), myReader.GetString(n+17), myReader.GetString(n+18), myReader.GetInt64(n+19));
                    csv.AppendLine(line);
                    n = 0;
                }
                System.IO.File.WriteAllText(filepath, csv.ToString());

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message.ToString());
            }

            if (myReader != null)
            {
                if (myReader.IsClosed == false)
                {
                    myReader.Close();
                    myReader.Dispose();
                }
            }

            if (conn != null)
            {
                if (conn.State == System.Data.ConnectionState.Open)
                {
                    conn.Close();
                    conn.Dispose();
                }
            }
        }

        public void LocalSetupInsert(my.MySqlClient.MySqlConnection conn) //alter for opscan
        {
            string strQuery = String.Empty;

            strQuery = string.Format("INSERT INTO app_performance.activity (username, domain, ipaddress, computer_name, process_name, process_path, process_starttime, processid, process_description, process_exittime, version, productname, companyname, semester, process_path_commandline, sid, fullname, department, role, idactivity) VALUES ('{0}', '{1}', '{2}', '{3}', '{4}', '{5}','{6}', '{7}', '{8}', '{9}', '{10}', '{11}','{12}', '{13}', '{14}', '{15}', '{16}', '{17}', '{18}', '{19}')");

            my.MySqlClient.MySqlCommand cmd = new my.MySqlClient.MySqlCommand(strQuery, conn);
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }

        [WebMethod]
        public void printSQLTable()
        {
            my.MySqlClient.MySqlConnection conn = connectToDatabase();
            if (conn != null)
            {
                if (conn.State == System.Data.ConnectionState.Open)
                {
                    LocalSetupGet(conn);
                }
            }
        }

        private void send_email(string to)
        {
            try
            {
                mail.MailMessage message;
                mail.SmtpClient smtp;
                message = new mail.MailMessage("aluthra1@pride.hofstra.edu", to, "Test", "Sample Body");
                mail.Attachment att1 = new mail.Attachment(@"C:\Users\fcs-bithub1\Documents\Hello.txt");
                //mail.Attachment att2 = new mail.Attachment(@"C:\Users\fcs-bithub1\Documents\Hello.txt");
                //mail.Attachment att3 = new mail.Attachment(@"C:\Users\fcs-bithub1\Documents\Hello.txt");
                message.Attachments.Add(att1);
                //message.Attachments.Add(att2);
                //message.Attachments.Add(att3);

                //----------------------------------------------------------------
                //SMTP INFORMATION

                smtp = new mail.SmtpClient("mta.hofstra.edu");
                smtp.Send(message);
                smtp.Dispose();

                Console.WriteLine("Report Has Been Sent!");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private void save_into_csv()//Need Object Type ex.Stock
        {
            try
            {
                var filepath = "NULL"; //Add A filepath - parameter?
                var csv = new System.Text.StringBuilder();
                int count = 0;
                //csv.AppendLine(line);

                System.IO.File.WriteAllText(filepath, csv.ToString());

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }

        }
        private void add_read_send(object sender, EventArgs e)
        {
            try
            {
                //Connect to Database
                my.MySqlClient.MySqlConnection conn = connectToDatabase();

                //Add Data to table using LocalSetupInsert - needs altering
                LocalSetupInsert(conn);

                //Read Data from table using LocalSetupGet
                LocalSetupGet(conn);

                //Save data into csv file
                //save_into_csv(results); 

                //close connection to table
                if (conn != null)
                {
                    if (conn.State == System.Data.ConnectionState.Open)
                    {
                        conn.Close();
                        conn.Dispose();
                    }
                }

                //call send_email function
                send_email("Bob.Khatami@Hofstra.edu");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }
    }
}
